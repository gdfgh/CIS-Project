import pygame
import random
import math

BLACK = (0,0,0)
WHITE = (255,255,255)
GREEN = (0,255,0)
RED = (255,0,0)

class Player(pygame.sprite.Sprite):

    def __init__(self, x, y):
        super().__init__()

        self.Right = pygame.image.load("Player.jpg").convert()
        self.Right.set_colorkey(WHITE)

        self.Left = pygame.transform.flip(pygame.image.load("Player.jpg").convert(), True, False)
        self.Left.set_colorkey(WHITE)

        self.image = self.Right

        self.rect = self.image.get_rect()

        self.rect.x = 350
        self.rect.y = 200

        self.change_x = 0
        self.change_y = 0

    def changespeed(self, x, y):
        self.change_x += x
        self.change_y += y

        if self.change_x > 0:
            self.image = self.Right
        elif self.change_x < 0:
            self.image = self.Left

    def update(self):
        self.rect.x += self.change_x
        self.rect.y += self.change_y

class Bullet(pygame.sprite.Sprite):
    def __init__(self, start_x, start_y, dest_x, dest_y):
        super().__init__()

        self.image = pygame.Surface([4,10])
        self.image.fill(BLACK)

        self.rect = self.image.get_rect()

        self.rect.x = start_x
        self.rect.y = start_y

        self.floating_point_x = start_x
        self.floating_point_y = start_y

        x_diff = dest_x - start_x
        y_diff = dest_y - start_y
        angle = math.atan2(y_diff, x_diff);

        velocity = 4
        self.change_x = math.cos(angle)*velocity
        self.change_y = math.sin(angle)*velocity

    def update(self):
        self.floating_point_y += self.change_y
        self.floating_point_x += self.change_x

        self.rect.y = int(self.floating_point_y)
        self.rect.x = int(self.floating_point_x)

        if self.rect.x < 0 or self.rect.x > 800 or self.rect.y <0 or self.rect.y > 600:
            self.kill()
# Map 1 platform layout    
def Map_1():
    pygame.draw.line(screen, WHITE, [0, 140], [300,140], 9)
    pygame.draw.line(screen, WHITE, [500,140], [800,140], 9)
    pygame.draw.line(screen, WHITE, [0,310], [200,310], 9)
    pygame.draw.line(screen, WHITE, [600,310], [800,310], 9)
    pygame.draw.line(screen, WHITE, [0,480], [300,480], 9)
    pygame.draw.line(screen, WHITE, [500,480], [800,480], 9)
    pygame.draw.line(screen, WHITE, [305, 250], [500,250],9)
    pygame.draw.line(screen, WHITE, [0,600], [800,600],9)

pygame.init()
 
# Set the width and height of the screen [width, height]
size = (800, 600)
screen = pygame.display.set_mode(size)
 
pygame.display.set_caption("Technically Stealing")

sprite_list = pygame.sprite.Group()

all_sprites_list = pygame.sprite.Group()

player = Player(350,200)
all_sprites_list.add(player)
# Loop until the user clicks the close button.
done = False
 
# Used to manage how fast the screen updates
clock = pygame.time.Clock()

# set pos of graphics
background_1_pos = [0,0]

# Load and set up graphics.
background_1_image = pygame.image.load("jungle.jpg").convert()

# -------- Main Program Loop -----------
while not done:
    # --- Main event loop
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
        # Press down a key
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_w:
                player.changespeed(0,-3)
            elif event.key == pygame.K_a:
                player.changespeed(-3,0)
            elif event.key == pygame.K_s:
                player.changespeed(0,3)
            elif event.key == pygame.K_d:
                player.changespeed(3,0)

        # Released key
        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_a:
                player.changespeed(3,0)
            elif event.key == pygame.K_d:
                player.changespeed(-3,0)
            elif event.key == pygame.K_w:
                player.changespeed(0,3)
            elif event.key == pygame.K_s:
                player.changespeed(0,-3)

        elif event.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()

            mouse_x = pos[0]
            mouse_y = pos[1]

            bullet = Bullet(player.rect.x, player.rect.y, mouse_x, mouse_y)

            all_sprites_list.add(bullet)
    # --- Game logic should go here
                                    
    # --- Screen-clearing code goes here
    # Here, we clear the screen to white. Don't put other drawing commands
    # above this, or they will be erased with this command.
    screen.fill(BLACK)
    # If you want a background image, replace this clear with blit'ing the
    # background image.
    screen.blit(background_1_image, background_1_pos)

    all_sprites_list.update()
    # --- Drawing code goes should go here.
    drawMap_1 = Map_1()
    all_sprites_list.draw(screen)
    # --- Go ahead and update the screen with what we've drawn.
    pygame.display.flip()
 
    # --- Limit to 60 frames per second
    clock.tick(60)

# Close the window and quit.
pygame.quit()
        
